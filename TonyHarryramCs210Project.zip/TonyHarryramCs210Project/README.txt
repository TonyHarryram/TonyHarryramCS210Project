This is a simple X86 8086 emulator that supports: AX, BX , CX , DX , DH , AH , CH , BH, and a few more of the basic registers, the functions such as ADD , SUB , INC , DEC , OR , AND , XOR are stable, while MOV, PUSH , POP , are more unstable. It does not support video memory or things like segments or interrupts.What the sample code does is read the input .com file and print out hello world, the ASCII Characters and the values of the registers. 

I essentiality I split the program into different segments, the instruction set, the commands and the registers, and had a separate piece of code for each of these.  This makes the code harder to follow but also far less cluttered if I were to try and put it all in the same place.This also means that all these files need to be kept together, including the include folder which contains all the header files. The main is the only one that needs to be compiled in gcc and run.

Full transparency: the code that I used for the example was from a codegolf competition that I figured would work well with what you asked us to do. I’ve linked it below.
https://codegolf.stackexchange.com/questions/4732/emulate-an-intel-8086-cpu/136505#136505

